<script>window.location = "{{route('login')}}";</script>
