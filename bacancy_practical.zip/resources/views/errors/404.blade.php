<script>window.location = "{{route('home')}}";</script>
