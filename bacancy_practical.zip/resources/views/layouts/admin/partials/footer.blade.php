<footer class="main-footer">
    <strong>Copyright &copy; <?= date('Y') ?> </strong> {{trans('common.all_rights_reserved')}}
</footer>