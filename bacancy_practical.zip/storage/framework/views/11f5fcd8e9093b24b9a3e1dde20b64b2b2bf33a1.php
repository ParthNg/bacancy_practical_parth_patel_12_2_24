<?php
$routename = Route::currentRouteName();
?>
<!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      
      
      <?php if(auth()->user()->user_type == 'admin'): ?>
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="<?php if($routename == 'home'): ?> active <?php endif; ?>">
          <a href="<?php echo e(route('home')); ?>">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
            <span class="pull-right-container">
            </span>
          </a>
        </li>
        
        <li class="<?php echo e((request()->is('admin/products*')) ? 'active' : ''); ?>">
          <a href="<?php echo e(route('products.index')); ?>">
            <i class="fa fa-user-o"></i> <span>Products</span>
          </a>
        </li>
        
        <li class="<?php echo e((request()->is('admin/setting*')) ? 'active' : ''); ?>">
          <a href="<?php echo e(route('setting.index')); ?>">
            <i class="fa fa-cog"></i> <span>Configurations</span>
          </a>
        </li> 
        
      </ul>
      <?php endif; ?>
    </section>
  </aside><?php /**PATH C:\xampp\htdocs\RND\bacancy\work\resources\views/layouts/admin/partials/sidebar.blade.php ENDPATH**/ ?>