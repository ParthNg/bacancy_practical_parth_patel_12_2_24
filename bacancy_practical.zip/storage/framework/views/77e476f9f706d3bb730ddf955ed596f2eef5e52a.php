
<?php $__env->startSection('css'); ?>
<style>
  .content-label::after {
    content: "*";
    color: red;
}
</style>
<?php $__env->stopSection(); ?> 
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
<section class="content-header">
  <h1>
    Configurations
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(route('home')); ?>"><i class="fa fa-dashboard"></i>Home</a></li>
    <li><a href="<?php echo e(route('setting.index')); ?>">Configurations</a></li>
  </ol>
</section>
    <section class="content">
    <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <b>Whoops</b>
        <ul>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    <?php endif; ?>
      <div class="row">
        <div class="col-md-12">
          <div class="box box-warning">
            <div class="box-body">
                <form action="<?php echo e(route('setting.update')); ?>" method="POST" id="setting" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                  <div class="modal-body">
                    <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="content" class="content-label"><?php echo e(ucwords(str_replace('_',' ',$k))); ?></label>
                          <input class="form-control" minlength="2" maxlength="255" placeholder="<?php echo e(trans('setting.'.strtolower($k))); ?>" name="<?php echo e($k); ?>" type="text" value="<?php echo e($v); ?>">
                          <?php $__errorArgs = [strtolower($k)];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="help-block"><?php echo e($message); ?></div>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      </div>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                  
                  <div class="modal-footer">
                    <button id="edit_btn" type="submit" class="btn btn-info btn-fill btn-wd">Save</button>
                  </div>
                </form>
            </div>
          </div>
        </div>
      </div>
    </section>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<script>
  $(document).ready(function () {

     $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
 
        $('#image').change(function(){
          
            let reader = new FileReader();
            reader.onload = (e) => { 
              $('#preview').attr('src', e.target.result); 
            }
            reader.readAsDataURL(this.files[0]); 
      });

    $('#setting').validate({
        errorClass: ".alert-danger",
        rules: {

            app_name: {
                required: true,
            },
            app_short_name: {
                required: true, 
            },
            email_username:{
                required: true,
                email: true
            },
            email_password:{
                required: true,
            },
            email_host:{
                required: true,
            },
            email_port:{
                required: true,
                digits: true,
            },
            email_encryption:{
                required: true,
            },
            email_from_name:{
                required: true,
            },
            email_from_address:{
                required: true,
                email: true,
            },
            commission_rate:{
                required: true,
                digits: true,
            },
            cancel_charge:{
                required: true,
                digits: true,
            }
        }
    });
});
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RND\bacancy\work\resources\views/admin/setting/index.blade.php ENDPATH**/ ?>