<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title> <?php echo e(@$app_settings['app_name']); ?> <?php if(@$page_title): ?> - <?php echo e($page_title); ?> <?php endif; ?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="icon" href="<?php echo e(asset('website/images/favicon.png')); ?>" type="image/x-icon">
  <!-- Bootstrap 3.3.7 -->
  <?php if(config('app.locales')[config('app.locale')]['dir'] == 'rtl'){ ?>
    <link rel="stylesheet" href="<?php echo e(asset('adminAsset/bower_components/bootstrap/dist-rtl/css/bootstrap.min.css')); ?> ">
  <?php }else{ ?>
    <link rel="stylesheet" href="<?php echo e(asset('adminAsset/bower_components/bootstrap/dist/css/bootstrap.min.css')); ?> ">
  <?php } ?>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(asset('adminAsset/bower_components/font-awesome/css/font-awesome.min.css')); ?> ">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo e(asset('adminAsset/bower_components/Ionicons/css/ionicons.min.css')); ?> ">
  <!-- Select2 -->
  <link rel="stylesheet" href="<?php echo e(asset('adminAsset/bower_components/select2/dist/css/select2.min.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/multiselect/multiselect.css')); ?>">
  <!-- <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css"> -->
  <!-- Theme style -->
  <?php if(config('app.locales')[config('app.locale')]['dir'] == 'rtl'){ ?>
    <link rel="stylesheet" href="<?php echo e(asset('adminAsset/dist-rtl/css/AdminLTE.css')); ?> ">
  <?php }else{ ?>
    <link rel="stylesheet" href="<?php echo e(asset('adminAsset/dist/css/AdminLTE.min.css')); ?> ">
  <?php } ?>

  <link rel="stylesheet" href="<?php echo e(asset('adminAsset/plugins/datetimepicker/bootstrap-datetimepicker.min.css')); ?>">

  <!-- <link rel="stylesheet" href="<?php echo e(asset('admin/dist/css/AdminLTE.min.css')); ?> "> -->
  <!-- iCheck -->
  <link rel="stylesheet" href="<?php echo e(asset('adminAsset/plugins/iCheck/square/blue.css')); ?> ">
  <?php if(config('app.locales')[config('app.locale')]['dir'] == 'rtl'){ ?>
      <link rel="stylesheet" href="<?php echo e(asset('adminAsset/dist-rtl/css/skins/_all-skins.min.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('adminAsset/dist-rtl/css/bootstrap-rtl.min.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('adminAsset/dist-rtl/css/profile.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('adminAsset/dist-rtl/css/rtl.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('adminAsset/custom/fonts/dubai_medium.css')); ?>">
  <?php }else{ ?>
      <link rel="stylesheet" href="<?php echo e(asset('adminAsset/dist/css/skins/_all-skins.min.css')); ?>">
  <?php } ?>



<style type="text/css">
.content-lable-astrisk::after {
    content: "*";
    color: red;
}
/* Loader */
#loader {
    left: 0%;
    top: 0%;
    width: 100%;
    height: 100%;
    position: fixed;
    
    opacity: 0.7;
    z-index: 9999999;
}

.overlay__inner {
    
    left: 50%;
    top: 20%;
    width: 10%;
    height: 30%;
    position: relative;
}

.overlay__content {
    left: 50%;
    position: absolute;
    top: 50%;
    background: #3c8dbc;
    transform: translate(-50%, -50%);
    padding: 20%;
}

.spinner {
    width: 75px;
    height: 75px;
    display: inline-block;
    border-width: 2px;
    border-color: rgba(255, 255, 255, 0.05);
    border-top-color: #fff;
    animation: spin 1s infinite linear;
    border-radius: 100%;
    border-style: solid;
}

@keyframes  spin {
  100% {
    transform: rotate(360deg);
  }
}
#loader{display: none}

.required_lable::after {
    content: "*";
    color: red;
}

#datalist_table_wrapper {overflow-x:scroll;}
  </style>
  
  <!-- CkEditor -->
  <script src="<?php echo e(asset('adminAsset/bower_components/ckeditor/ckeditor.js')); ?>"></script>

  <!-- Toaster -->
  <link rel="stylesheet" href="<?php echo e(asset('css/toastr.min.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('adminAsset/custom/developer.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/select.dataTables.min.css')); ?>" />
  <!-- Datatable Checkbox CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('css/dataTables.checkboxes.css')); ?>" />
  
  <?php echo $__env->yieldContent('css'); ?>
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition skin-blue sidebar-mini">
  <div class="wrapper">
    <audio id="beepAudio" preload="auto" src="<?php echo e(asset('website/beep.mp3')); ?>"></audio>
    

  <?php echo $__env->make('layouts.admin.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
  <?php echo $__env->make('layouts.admin.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
      <?php echo $__env->yieldContent('content'); ?>
  <?php echo $__env->make('layouts.admin.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</div>
<!-- For Multi Select -->
<script src="<?php echo e(asset('js/multiselect/multiselect.min.js')); ?>"></script>
<script>
    document.multiselect('.multiselect1');
</script>

<!-- jQuery 3 -->
<script src="<?php echo e(asset('adminAsset/bower_components/jquery/dist/jquery.min.js')); ?> "></script>
<!-- Bootstrap 3.3.7 -->

<?php if(config('app.locales')[config('app.locale')]['dir'] == 'rtl' ){ ?>
    <script src="<?php echo e(asset('adminAsset/bower_components/bootstrap/dist-rtl/js/bootstrap.min.js')); ?>"></script>
<?php }else{ ?>
    <script src="<?php echo e(asset('adminAsset/bower_components/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
<?php } ?>

<script src="<?php echo e(asset('adminAsset/plugins/datetimepicker/moment-with-locales.js')); ?>"></script>
<script src="<?php echo e(asset('adminAsset/plugins/datetimepicker/bootstrap-datetimepicker.min.js')); ?>"></script>
<!-- SlimScroll -->
<script src="<?php echo e(asset('adminAsset/bower_components/jquery-slimscroll/jquery.slimscroll.min.js')); ?>"></script>
<!-- FastClick -->
<script src="<?php echo e(asset('adminAsset/bower_components/fastclick/lib/fastclick.js')); ?>"></script>
<!-- adminAssetLTE App -->
<?php if(config('app.locales')[config('app.locale')]['dir'] == 'rtl' ){ ?>
    <script src="<?php echo e(asset('adminAsset/dist-rtl/js/adminlte.min.js')); ?>"></script>
<?php }else{ ?>
    <script src="<?php echo e(asset('adminAsset/dist/js/adminlte.min.js')); ?>"></script>
<?php } ?>

<!-- AdminLTE for demo purposes -->
<?php if(config('app.locales')[config('app.locale')]['dir'] == 'rtl' ){ ?>
    <script src="<?php echo e(asset('adminAsset/dist-rtl/js/demo.js')); ?>"></script>
<?php }else{ ?>
    <script src="<?php echo e(asset('adminAsset/dist/js/demo.js')); ?>"></script>
<?php } ?>



<!-- DataTables -->
<script src="<?php echo e(asset('adminAsset/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('adminAsset/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dataTables.select.min.js')); ?>"></script>
<!-- DataTables Checkbox -->
<script src="<?php echo e(asset('js/dataTables.checkboxes.min.js')); ?>"></script>
<script>
  $(document).ready(function () {
    <?php if(config('app.locales')[config('app.locale')]['dir'] != 'rtl' ){ ?>
        $('.sidebar-menu').tree()
    <?php }?>
  })
</script>
<!--Toaster JS-->
<script src="<?php echo e(asset('js/toastr.min.js')); ?>"></script>

<script type="text/javascript">
    <?php if(Session::has('success')): ?>
      toastr.success("<?php echo e(Session::get('success')); ?>");
    <?php elseif(Session::has('error')): ?>
      toastr.error("<?php echo e(Session::get('error')); ?>");
    <?php elseif(Session::has('warning')): ?>
      toastr.warning("<?php echo e(Session::get('warning')); ?>");
    <?php elseif(Session::has('info')): ?>
      toastr.info("<?php echo e(Session::get('info')); ?>");
    <?php endif; ?>
</script>

<script type="text/javascript"> 
     
  $('.alert-danger').delay(5000).fadeOut();

   function isNumber(evt) {
          var iKeyCode = (evt.which) ? evt.which : evt.keyCode
          if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
              return false;

          return true;
      }  
</script>

<script type="text/javascript"> 
  $(document).ready(function(){ 
    $('.error').delay(5000).fadeOut();
    $('.multiselect-checkbox').next().first().html("<?php echo e(trans('common.all')); ?>");
    $('.select2').select2();
  });

  $('form').submit(function(){
    $('#edit_btn').prop('disabled', true);
  })

  $('.multiselect-input').attr('autocomplete','off');
    
</script>

<script type="text/javascript" src="<?php echo e(asset('adminAsset/custom/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('adminAsset/bower_components/select2/dist/js/select2.full.min.js')); ?>"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<!-- WEB PUSH NOTOFOCTION -->

<script type="text/javascript">
  var lang_url = '';

</script>
<?php echo $__env->yieldContent('js'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\RND\bacancy\work\resources\views/layouts/admin/app.blade.php ENDPATH**/ ?>