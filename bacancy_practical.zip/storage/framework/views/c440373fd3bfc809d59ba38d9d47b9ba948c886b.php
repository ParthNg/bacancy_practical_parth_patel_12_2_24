<footer class="main-footer">
    <strong>Copyright &copy; <?= date('Y') ?> </strong> <?php echo e(trans('common.all_rights_reserved')); ?>

</footer><?php /**PATH C:\xampp\htdocs\RND\bacancy\work\resources\views/layouts/admin/partials/footer.blade.php ENDPATH**/ ?>