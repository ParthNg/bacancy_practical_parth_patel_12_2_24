<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php echo e(config('adminlte.name', 'Laravel')); ?> <?php if(@$page_title): ?> - <?php echo e($page_title); ?> <?php endif; ?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="icon" href="<?php echo e(asset('website/images/favicon.png')); ?>" type="image/x-icon">
  <?php if(config('app.locales')[config('app.locale')]['dir'] == 'rtl'){ ?>
    <link rel="stylesheet" href="<?php echo e(asset('adminAsset/bower_components/bootstrap/dist-rtl/css/bootstrap.min.css')); ?> ">
  <?php }else{ ?>
    <link rel="stylesheet" href="<?php echo e(asset('adminAsset/bower_components/bootstrap/dist/css/bootstrap.min.css')); ?> ">
  <?php } ?>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(asset('adminAsset/bower_components/font-awesome/css/font-awesome.min.css')); ?> ">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo e(asset('adminAsset/bower_components/Ionicons/css/ionicons.min.css')); ?> ">
  <!-- Select2 -->
  <link rel="stylesheet" href="<?php echo e(asset('adminAsset/bower_components/select2/dist/css/select2.min.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/multiselect/multiselect.css')); ?>">
  <!-- Theme style -->
  <?php if(config('app.locales')[config('app.locale')]['dir'] == 'rtl'){ ?>
    <link rel="stylesheet" href="<?php echo e(asset('adminAsset/dist-rtl/css/AdminLTE.css')); ?> ">
  <?php }else{ ?>
    <link rel="stylesheet" href="<?php echo e(asset('adminAsset/dist/css/AdminLTE.min.css')); ?> ">
  <?php } ?>

  <!-- iCheck -->
  <link rel="stylesheet" href="<?php echo e(asset('adminAsset/plugins/iCheck/square/blue.css')); ?> ">

  <?php if(config('app.locales')[config('app.locale')]['dir'] == 'rtl'){ ?>
    <link rel="stylesheet" href="<?php echo e(asset('adminAsset/custom/fonts/dubai_medium.css')); ?>">
  <?php } ?>   


  <!-- Toaster -->
  <link rel="stylesheet" href="<?php echo e(asset('css/toastr.min.css')); ?>" />
  <?php echo $__env->yieldContent('css'); ?>
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition login-page" style="background: #e5e5e5">
  <div class="login-box">
    <?php if(count($errors) > 0): ?>
          <div class="alert alert-danger">
              <strong><?php echo e(trans('auth.error')); ?>!</strong> <?php echo e(trans('auth.input_error')); ?><br><br>
              <ul class="list-group">
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li class="list-group-item list-group-item-danger"><?php echo e($error); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
          </div>
    <?php endif; ?>

    <?php if(Session::has('message')): ?>
        <div class="alert alert-success">
          <?php echo e(Session::get('message')); ?>

        </div>
    <?php endif; ?>

    <?php if(Session::has('error_message')): ?>
        <div class="alert alert-danger">
          <?php echo e(Session::get('error_message')); ?>

        </div>
    <?php endif; ?>
    <div class="login-logo">
      <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('website/images/logo.png')); ?>" style="width:80%"></a>
    </div>
    <?php echo $__env->yieldContent('content'); ?>
  </div>

<!-- /.login-box -->
<!-- For Multi Select -->
<script src="<?php echo e(asset('js/multiselect/multiselect.min.js')); ?>"></script>
<script>
    document.multiselect('.multiselect1');
</script>

<!-- jQuery 3 -->
<script src="<?php echo e(asset('adminAsset/bower_components/jquery/dist/jquery.min.js')); ?> "></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo e(asset('adminAsset/bower_components/bootstrap/dist/js/bootstrap.min.js')); ?> "></script>
<!-- SlimScroll -->
<script src="<?php echo e(asset('adminAsset/bower_components/jquery-slimscroll/jquery.slimscroll.min.js')); ?>"></script>
<!-- FastClick -->
<script src="<?php echo e(asset('adminAsset/bower_components/fastclick/lib/fastclick.js')); ?>"></script>
<!-- adminAssetLTE App -->
<script src="<?php echo e(asset('adminAsset/dist/js/adminlte.min.js')); ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo e(asset('adminAsset/dist/js/demo.js')); ?>"></script>
<!--Toaster JS-->
<script src="<?php echo e(asset('js/toastr.min.js')); ?>"></script>
<link rel="stylesheet" href="<?php echo e(asset('adminAsset/bower_components/select2/dist/js/select2.full.min.js')); ?>">
<script>
  $(document).ready(function () {
    $('.sidebar-menu').tree()
    $('.multiselect-checkbox').next().first().html("<?php echo e(trans('common.all')); ?>");

    $('.select2').select2();
  })
</script>
<?php echo $__env->yieldContent('js'); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\RND\bacancy\work\resources\views/layouts/app.blade.php ENDPATH**/ ?>