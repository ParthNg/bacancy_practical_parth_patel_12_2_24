<?php
return [

	// dashboard configurations
    'name' => 'Inventory System',
	'small_logo' => '<b>IS</b>',
	'logo' => '<b>Inventory System</b>',
];

?>